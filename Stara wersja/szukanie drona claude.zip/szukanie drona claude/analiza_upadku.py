# -*- coding: utf-8 -*-
"""
Ekstrapolacja miejsca upadku ROZBROJONEGO drona.
Silniki stanely -> brak ciagu -> predkosc pozioma wyhamowuje z oporem powietrza,
dron spada z predkoscia terminalna (spadanie z dryfem).
"""

import math
import json

# Ostatnie znane wartosci z pliku (zamrozone w telemetrii po utracie sygnalu)
LAT0 = 53.487867
LON0 = 14.894972
ALT = 233.0          # wysokosc [m]
HDG_DEG = 130.30     # kurs (0 = N, zgodnie z ruchem wskazowek zegara)
GSPD_KMH = 39.5      # predkosc naziemna [km/h]

GSPD_MS = GSPD_KMH / 3.6  # 10.97 m/s

# Konwersja metrow -> stopnie
DEG_LAT_PER_M = 1.0 / 111320.0
DEG_LON_PER_M = 1.0 / (111320.0 * math.cos(math.radians(LAT0)))

hdg_rad = math.radians(HDG_DEG)
dir_N = math.cos(hdg_rad)
dir_E = math.sin(hdg_rad)

G = 9.81  # m/s^2
RHO = 1.225  # gestosc powietrza [kg/m^3]


def simulate_disarmed(mass_kg, area_m2, Cd, label):
    """
    Symulacja balistyczna rozbrojonego drona (silniki OFF).
    Krok czasowy - dt. Dron spada z oporem powietrza w 2D (pion + poziom).
    """
    dt = 0.02
    t = 0.0
    # pozycja w lokalnym ukladzie (x = w kierunku kursu, z = wysokosc)
    x = 0.0
    z = ALT
    vx = GSPD_MS   # poczatkowa predkosc pozioma (w kierunku kursu)
    vz = 0.0       # pionowa zaczyna od zera (lot poziomy)
    # wspolczynnik oporu: F_drag = 0.5 * rho * v^2 * Cd * A
    # a_drag = 0.5 * rho * A * Cd / m * v^2 (w kierunku przeciwnym do predkosci)
    k = 0.5 * RHO * area_m2 * Cd / mass_kg

    while z > 0 and t < 120:
        v = math.sqrt(vx*vx + vz*vz)
        # przyspieszenie oporu (w kierunku przeciwnym do wektora predkosci)
        if v > 0:
            a_drag = k * v * v
            ax = -a_drag * (vx / v)
            az_drag = -a_drag * (vz / v)
        else:
            ax = 0
            az_drag = 0
        az = -G + az_drag  # grawitacja w dol (z maleje) + opor
        # uwaga: vz > 0 oznacza "w gore", vz < 0 "w dol"
        # az < 0 przyspiesza w dol
        vx += ax * dt
        vz += az * dt
        x  += vx * dt
        z  += vz * dt
        t  += dt

    # x - przebyta droga pozioma w kierunku kursu
    v_final_h = vx
    v_final_v = -vz  # predkosc pionowa w dol (dodatnia)

    dN_m = dir_N * x
    dE_m = dir_E * x
    lat = LAT0 + dN_m * DEG_LAT_PER_M
    lon = LON0 + dE_m * DEG_LON_PER_M

    print(f"\n--- {label} ---")
    print(f"  masa={mass_kg}kg, A={area_m2}m^2, Cd={Cd}")
    print(f"  czas upadku:      {t:.1f} s")
    print(f"  droga pozioma:    {x:.0f} m (kurs {HDG_DEG}, SE)")
    print(f"  v pozioma finalna: {v_final_h:.2f} m/s  (start {GSPD_MS:.2f})")
    print(f"  v pionowa finalna: {v_final_v:.2f} m/s")
    print(f"  miejsce upadku:   {lat:.6f}, {lon:.6f}")
    print(f"  Google Maps:      https://www.google.com/maps?q={lat:.6f},{lon:.6f}")

    return {
        "label": label,
        "lat": lat, "lon": lon,
        "t": t, "dist": x,
        "vh": v_final_h, "vv": v_final_v,
    }

print("="*70)
print("UPADEK ROZBROJONEGO DRONA - symulacja balistyczna z oporem powietrza")
print("="*70)
print(f"Start: {LAT0}, {LON0}, alt={ALT}m, hdg={HDG_DEG} (SE), v_poz={GSPD_KMH} km/h")
print(f"Rozbrojenie = silniki OFF => brak ciagu, poziomy momentum szybko zanika")

results = []
# Typowe konfiguracje dronow FPV
# Lekki 5" freestyle: ~0.5kg, A~0.02-0.03 m^2 (tumbling), Cd~0.8-1.0
# Ciezszy 5" HD / 7": ~0.8-1.2kg
# Drag coefficient quada tumble: ~0.8 (kwadratowa rama, burzliwe oplywanie)

results.append(simulate_disarmed(0.5, 0.025, 0.8, "Lekki 5\" freestyle (~0.5kg)"))
results.append(simulate_disarmed(0.7, 0.03,  0.8, "Sredni FPV (~0.7kg) - prawdopodobne"))
results.append(simulate_disarmed(1.0, 0.035, 0.9, "Ciezszy HD/7\" (~1.0kg)"))
# Warianty skrajne:
results.append(simulate_disarmed(0.5, 0.05,  1.2, "Maksymalny opor (flat-spin, duzy Cd)"))
results.append(simulate_disarmed(1.2, 0.02,  0.6, "Minimalny opor (spada nosem, maly Cd)"))

# Dla porownania - punkt ostatniego kontaktu
print("\n" + "="*70)

# Generuj mape
markers = [
    {"lat": LAT0, "lon": LON0, "label": "OSTATNI KONTAKT (utrata sygnalu)",
     "color": "#000080", "radius": 12,
     "info": f"Alt {ALT}m, hdg {HDG_DEG}, v_poz {GSPD_KMH} km/h. Tu silniki stanely."}
]
colors = ["#e6194b", "#3cb44b", "#f58231", "#ffe119", "#911eb4"]
for r, c in zip(results, colors):
    markers.append({
        "lat": r["lat"], "lon": r["lon"],
        "label": r["label"],
        "color": c, "radius": 11,
        "info": f"Droga pozioma: {r['dist']:.0f}m, czas upadku: {r['t']:.1f}s, v_koncowa: {r['vv']:.1f} m/s w dol"
    })

data_json = json.dumps(markers, ensure_ascii=False)

html = r"""<!DOCTYPE html>
<html lang="pl">
<head>
<meta charset="UTF-8">
<title>Miejsce upadku rozbrojonego drona - PolandFPV2-2000-01-01-000814</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<style>
  html,body{margin:0;padding:0;height:100%;font-family:sans-serif;}
  #map{position:absolute;top:0;bottom:0;left:0;right:360px;}
  #side{position:absolute;top:0;bottom:0;right:0;width:360px;overflow-y:auto;
        background:#f6f6f6;border-left:1px solid #ccc;padding:10px;box-sizing:border-box;font-size:13px;}
  h2{margin:0 0 8px 0;font-size:15px;}
  .item{padding:6px;margin-bottom:4px;background:#fff;border:1px solid #ddd;border-radius:4px;cursor:pointer;}
  .item:hover{background:#eef;}
  .sw{display:inline-block;width:12px;height:12px;border-radius:50%;margin-right:6px;vertical-align:middle;border:1px solid #333;}
  .note{background:#fff3cd;border:1px solid #ffc107;padding:6px;border-radius:4px;font-size:12px;margin-bottom:8px;}
</style>
</head>
<body>
<div id="map"></div>
<div id="side">
<h2>Upadek rozbrojonego drona</h2>
<div class="note">
Dron byl <b>rozbrojony</b> = silniki wylaczone. Spada balistycznie z predkoscia
terminalna ~18-22 m/s, ale prędkosc pozioma (39.5 km/h) szybko zanika przez opor powietrza.
Promien poszukiwan: <b>~40-90m na SE</b> od punktu utraty sygnalu.
</div>
<h2>Scenariusze (rozne masy/Cd)</h2>
<div id="list"></div>
</div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
const MARKERS = __DATA__;
const map = L.map('map');
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; OpenStreetMap'}).addTo(map);
const list = document.getElementById('list');
const lls = [];

// Okrag pokazujacy prawdopodobny obszar poszukiwan wokol "sredniego" scenariusza (markers[2])
const mid = MARKERS[2];
L.circle([mid.lat, mid.lon], {radius: 40, color:'#3cb44b', fillColor:'#3cb44b', fillOpacity:0.15, weight:2}).addTo(map)
  .bindTooltip('Obszar ~40m wokol najbardziej prawdopodobnego miejsca');

// Linie
for (let i = 1; i < MARKERS.length; i++) {
  L.polyline([[MARKERS[0].lat,MARKERS[0].lon],[MARKERS[i].lat,MARKERS[i].lon]],
    {color:MARKERS[i].color, weight:2, opacity:0.6, dashArray:'5,5'}).addTo(map);
}

MARKERS.forEach(m => {
  lls.push([m.lat,m.lon]);
  const mk = L.circleMarker([m.lat,m.lon],{
    radius:m.radius,color:'#000',fillColor:m.color,fillOpacity:0.9,weight:2
  }).addTo(map);
  const gm = `https://www.google.com/maps?q=${m.lat.toFixed(6)},${m.lon.toFixed(6)}`;
  mk.bindPopup(`<b>${m.label}</b><br>${m.info}<br>
    <code>${m.lat.toFixed(6)}, ${m.lon.toFixed(6)}</code><br>
    <a href="${gm}" target="_blank">Google Maps</a>`);

  const row = document.createElement('div');
  row.className='item';
  row.innerHTML = `<div><span class="sw" style="background:${m.color}"></span><b>${m.label}</b></div>
    <div style="font-size:11px;color:#666;">${m.info}</div>
    <div style="font-size:11px;"><code>${m.lat.toFixed(6)}, ${m.lon.toFixed(6)}</code></div>
    <div><a href="${gm}" target="_blank">Google Maps</a></div>`;
  row.onclick = () => { map.setView([m.lat,m.lon], 19); mk.openPopup(); };
  list.appendChild(row);
});

map.fitBounds(lls,{padding:[60,60]});
</script>
</body>
</html>
"""

with open("mapa_upadku.html", "w", encoding="utf-8") as f:
    f.write(html.replace("__DATA__", data_json))

print("Zapisano mape: mapa_upadku.html")
print()
print("REKOMENDACJA: szukaj w promieniu ~30-40m wokol:")
print(f"  {results[1]['lat']:.6f}, {results[1]['lon']:.6f}")
print(f"  https://www.google.com/maps?q={results[1]['lat']:.6f},{results[1]['lon']:.6f}")
