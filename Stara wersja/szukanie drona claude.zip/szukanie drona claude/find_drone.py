# -*- coding: utf-8 -*-
"""
Szuka koordynatow GPS drona w plikach CSV z logow aparatury.
Filtruje te zaczynajace sie od szerokosci 53 i dlugosci 14 lub 15.
Generuje interaktywna mape HTML + liste plikow z linkami do Google Maps.
"""

import csv
import glob
import json
import os
import sys

LAT_PREFIX = "53"
LON_PREFIXES = ("14", "15")

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_HTML = os.path.join(HERE, "mapa_drona.html")
OUT_TXT = os.path.join(HERE, "znalezione_koordynaty.txt")


def open_csv(path):
    """Probuje utf-8, potem cp1250. Zwraca tekst."""
    for enc in ("utf-8-sig", "utf-8", "cp1250", "latin-1"):
        try:
            with open(path, "r", encoding=enc, newline="") as f:
                return f.read()
        except UnicodeDecodeError:
            continue
    with open(path, "r", encoding="utf-8", errors="replace", newline="") as f:
        return f.read()


def find_gps_column(fieldnames):
    if not fieldnames:
        return None
    for name in fieldnames:
        if name and "gps" in name.lower():
            return name
    return None


def parse_file(path):
    """Zwraca liste punktow (time, lat, lon, alt, sats, gspd) pasujacych do filtra."""
    text = open_csv(path)
    if not text.strip():
        return []
    reader = csv.DictReader(text.splitlines())
    gps_col = find_gps_column(reader.fieldnames)
    if not gps_col:
        return []

    time_col = None
    alt_col = None
    sats_col = None
    gspd_col = None
    for name in reader.fieldnames:
        low = (name or "").lower()
        if time_col is None and low == "time":
            time_col = name
        if alt_col is None and "alt" in low:
            alt_col = name
        if sats_col is None and "sats" in low:
            sats_col = name
        if gspd_col is None and "gspd" in low:
            gspd_col = name

    points = []
    for row in reader:
        try:
            gps = (row.get(gps_col) or "").strip()
        except Exception:
            continue
        if not gps:
            continue
        parts = gps.split()
        if len(parts) != 2:
            continue
        lat_s, lon_s = parts[0], parts[1]
        if not lat_s.startswith(LAT_PREFIX):
            continue
        if not any(lon_s.startswith(p) for p in LON_PREFIXES):
            continue
        try:
            lat = float(lat_s)
            lon = float(lon_s)
        except ValueError:
            continue
        points.append({
            "time": (row.get(time_col) or "").strip() if time_col else "",
            "lat": lat,
            "lon": lon,
            "alt": (row.get(alt_col) or "").strip() if alt_col else "",
            "sats": (row.get(sats_col) or "").strip() if sats_col else "",
            "gspd": (row.get(gspd_col) or "").strip() if gspd_col else "",
        })
    return points


PALETTE = [
    "#e6194b", "#3cb44b", "#ffe119", "#4363d8", "#f58231",
    "#911eb4", "#46f0f0", "#f032e6", "#bcf60c", "#fabebe",
    "#008080", "#e6beff", "#9a6324", "#fffac8", "#800000",
    "#aaffc3", "#808000", "#ffd8b1", "#000075", "#808080",
]


def build_html(by_file):
    """by_file: dict nazwa_pliku -> lista punktow."""
    tracks = []
    for i, (fname, pts) in enumerate(by_file.items()):
        if not pts:
            continue
        tracks.append({
            "file": fname,
            "color": PALETTE[i % len(PALETTE)],
            "points": pts,
        })

    data_json = json.dumps(tracks, ensure_ascii=False)

    html = r"""<!DOCTYPE html>
<html lang="pl">
<head>
<meta charset="UTF-8">
<title>Mapa drona - ostatnie koordynaty GPS</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<style>
  html, body { margin:0; padding:0; height:100%; font-family: sans-serif; }
  #map { position:absolute; top:0; bottom:0; left:0; right:360px; }
  #side {
    position:absolute; top:0; bottom:0; right:0; width:360px;
    overflow-y:auto; background:#f6f6f6; border-left:1px solid #ccc;
    padding:10px; box-sizing:border-box; font-size:13px;
  }
  #side h2 { margin:0 0 8px 0; font-size:16px; }
  .file-row {
    padding:6px; margin-bottom:4px; background:#fff; border:1px solid #ddd;
    border-radius:4px; cursor:pointer;
  }
  .file-row:hover { background:#eef; }
  .file-row .name { font-weight:bold; word-break:break-all; }
  .file-row .meta { color:#666; font-size:11px; }
  .swatch { display:inline-block; width:10px; height:10px; border-radius:50%; margin-right:6px; vertical-align:middle; }
  .popup-name { font-weight:bold; user-select:all; cursor:text; }
  .copy-btn {
    display:inline-block; padding:2px 6px; margin-top:4px; font-size:11px;
    background:#4363d8; color:white; border:none; border-radius:3px; cursor:pointer;
  }
  .legend { margin-top:6px; font-size:11px; color:#333; }
</style>
</head>
<body>
<div id="map"></div>
<div id="side">
  <h2>Znalezione pliki z GPS</h2>
  <div class="legend">Duzy czerwony pin = OSTATNI punkt lotu (mozliwe miejsce upadku). Klik w pinezke pokaze nazwe pliku.</div>
  <div id="file-list"></div>
</div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
const TRACKS = __DATA__;

const map = L.map('map');
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  attribution: '&copy; OpenStreetMap'
}).addTo(map);

const allLatLngs = [];
const fileList = document.getElementById('file-list');

function escapeHtml(s){ return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

function makePopup(file, p, isLast){
  const gmaps = `https://www.google.com/maps?q=${p.lat},${p.lon}`;
  return `
    <div>
      ${isLast ? '<div style="color:#e6194b;font-weight:bold;">OSTATNI PUNKT</div>' : ''}
      <div class="popup-name">${escapeHtml(file)}</div>
      <div>Lat: <code>${p.lat}</code></div>
      <div>Lon: <code>${p.lon}</code></div>
      <div>Czas: ${escapeHtml(p.time || '-')}</div>
      <div>Alt: ${escapeHtml(p.alt || '-')} m, Sats: ${escapeHtml(p.sats || '-')}, GSpd: ${escapeHtml(p.gspd || '-')}</div>
      <div style="margin-top:4px;">
        <a href="${gmaps}" target="_blank">Otworz w Google Maps</a>
      </div>
      <button class="copy-btn" onclick="navigator.clipboard.writeText('${file.replace(/'/g,"\\'")}').then(()=>this.innerText='Skopiowano!')">Kopiuj nazwe pliku</button>
    </div>
  `;
}

TRACKS.forEach((track, idx) => {
  const latlngs = track.points.map(p => [p.lat, p.lon]);
  latlngs.forEach(ll => allLatLngs.push(ll));

  // linia trasy
  if (latlngs.length > 1) {
    L.polyline(latlngs, {color: track.color, weight: 2, opacity: 0.7}).addTo(map);
  }

  // male markery dla wszystkich punktow
  track.points.forEach((p, i) => {
    const isLast = (i === track.points.length - 1);
    if (isLast) return; // ostatni pokazemy osobno jako czerwony duzy
    const marker = L.circleMarker([p.lat, p.lon], {
      radius: 3, color: track.color, fillColor: track.color, fillOpacity: 0.8, weight: 1
    }).addTo(map);
    marker.bindPopup(makePopup(track.file, p, false));
  });

  // ostatni punkt - duzy czerwony
  const last = track.points[track.points.length - 1];
  if (last) {
    const lastMarker = L.circleMarker([last.lat, last.lon], {
      radius: 10, color: '#000', fillColor: '#e6194b', fillOpacity: 1, weight: 2
    }).addTo(map);
    lastMarker.bindPopup(makePopup(track.file, last, true));
  }

  // wpis na liscie bocznej
  const row = document.createElement('div');
  row.className = 'file-row';
  row.innerHTML = `
    <div><span class="swatch" style="background:${track.color}"></span><span class="name">${escapeHtml(track.file)}</span></div>
    <div class="meta">${track.points.length} punktow. Ostatni: ${last.lat.toFixed(6)}, ${last.lon.toFixed(6)}</div>
  `;
  row.onclick = () => {
    map.setView([last.lat, last.lon], 17);
  };
  fileList.appendChild(row);
});

if (allLatLngs.length > 0) {
  map.fitBounds(allLatLngs, {padding: [30, 30]});
} else {
  map.setView([53.45, 15.05], 13);
}
</script>
</body>
</html>
"""
    return html.replace("__DATA__", data_json)


def main():
    csv_files = sorted(glob.glob(os.path.join(HERE, "**", "*.csv"), recursive=True))
    # filter lock files just in case (glob already ignores .csv#)
    csv_files = [p for p in csv_files if not p.endswith(".csv#")]

    print(f"Znaleziono {len(csv_files)} plikow CSV. Parsowanie...")

    by_file = {}
    total_points = 0
    files_with_gps = 0

    for path in csv_files:
        name = os.path.basename(path)
        try:
            pts = parse_file(path)
        except Exception as e:
            print(f"  BLAD w pliku {name}: {e}", file=sys.stderr)
            continue
        if pts:
            by_file[name] = pts
            total_points += len(pts)
            files_with_gps += 1

    print(f"Plikow z pasujacymi koordynatami: {files_with_gps}")
    print(f"Lacznie punktow GPS (lat=53.x, lon=14.x lub 15.x): {total_points}")

    # TXT z lista
    with open(OUT_TXT, "w", encoding="utf-8") as f:
        f.write(f"=== PODSUMOWANIE: {files_with_gps} plikow, {total_points} punktow GPS ===\n")
        f.write(f"Filtr: szerokosc zaczyna sie od {LAT_PREFIX}, dlugosc zaczyna sie od {' lub '.join(LON_PREFIXES)}\n\n")
        # sortuj: najwiecej punktow najpierw (to pewnie rzeczywiste loty)
        for fname, pts in sorted(by_file.items(), key=lambda kv: -len(kv[1])):
            last = pts[-1]
            first = pts[0]
            f.write(f"[{fname}] - {len(pts)} punktow\n")
            f.write(f"  Pierwszy: {first['lat']:.6f}, {first['lon']:.6f}  (czas: {first['time']})\n")
            f.write(f"  Ostatni:  {last['lat']:.6f}, {last['lon']:.6f}  (czas: {last['time']}, alt: {last['alt']}m, sats: {last['sats']})\n")
            f.write(f"  Google Maps (ostatni punkt): https://www.google.com/maps?q={last['lat']},{last['lon']}\n")
            f.write("\n")
        f.write("\n=== WSZYSTKIE KOORDYNATY (kopiuj do wyszukiwarki) ===\n")
        for fname, pts in sorted(by_file.items(), key=lambda kv: -len(kv[1])):
            f.write(f"\n--- {fname} ---\n")
            for p in pts:
                f.write(f"{p['lat']:.6f}, {p['lon']:.6f}\n")

    # HTML z mapa
    html = build_html(by_file)
    with open(OUT_HTML, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"\nZapisano:")
    print(f"  Mapa:  {OUT_HTML}")
    print(f"  Lista: {OUT_TXT}")
    print(f"\nOtworz mape_drona.html w przegladarce (Chrome/Edge).")


if __name__ == "__main__":
    main()
